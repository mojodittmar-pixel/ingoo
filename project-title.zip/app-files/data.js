var APP_DATA = {
  "scenes": [
    {
      "id": "0-img_20250909_174457_039",
      "name": "IMG_20250909_174457_039",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1488,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.6974571564165366,
          "pitch": 0.29991944505879786,
          "rotation": 0,
          "target": "1-img_20250909_174501_646"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-img_20250909_174501_646",
      "name": "IMG_20250909_174501_646",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1488,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.9324795998645428,
          "pitch": 0.15870566194847768,
          "rotation": 0,
          "target": "0-img_20250909_174457_039"
        },
        {
          "yaw": 3.0125651629924697,
          "pitch": 0.1412166589082844,
          "rotation": 0,
          "target": "3-img_20250909_174510_866"
        },
        {
          "yaw": 2.6342956544186995,
          "pitch": 0.1328026125492059,
          "rotation": 0,
          "target": "4-img_20250909_174506_324"
        },
        {
          "yaw": 1.8887336323389068,
          "pitch": 0.21483116216809073,
          "rotation": 0,
          "target": "2-img_20250909_173931_899"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-img_20250909_173931_899",
      "name": "IMG_20250909_173931_899",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1488,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.700317073109975,
          "pitch": 0.20328521158931778,
          "rotation": 0,
          "target": "1-img_20250909_174501_646"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-img_20250909_174510_866",
      "name": "IMG_20250909_174510_866",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1488,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -3.037560114458449,
          "pitch": 0.25556066532331556,
          "rotation": 0,
          "target": "1-img_20250909_174501_646"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-img_20250909_174506_324",
      "name": "IMG_20250909_174506_324",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1488,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.0263048536029338,
          "pitch": 0.28684370467730247,
          "rotation": 0,
          "target": "1-img_20250909_174501_646"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
